package cn.monitor4all.miaoshaservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MiaoshaServiceApplicationTests {

    @Test
    void contextLoads() {
    }

}
