package cn.monitor4all.miaoshadao;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MiaoshaDaoApplication {

    public static void main(String[] args) {
        SpringApplication.run(MiaoshaDaoApplication.class, args);
    }

}
