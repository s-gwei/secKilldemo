package com.baizhi.dao;

import com.baizhi.entity.Order;

public interface OrderDAO {
    //创建订单方法
    void createOrder(Order order);
}
