package cn.monitor4all.miaoshadao;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MiaoshaDaoApplicationTests {

    @Test
    void contextLoads() {
    }

}
